# Vynox Studio — Create Beyond Limits

**Vynox Studio** is a professional mobile-first video editing Android application inspired by high-end mobile editors like KineMaster and CapCut. Built natively with **Jetpack Compose**, **AndroidX Media3 (ExoPlayer & Transformer)**, and **Room Database**, Vynox Studio delivers real timeline-based editing and **100% watermark-free export**.

---

## 🌟 Key Features

### 1. Brand Identity & UI/UX
- **Premium Dark Workspace**: Charcoal and obsidian surfaces (`#0A0A0F`, `#12111A`) accented with glowing **Neon Purple** (`#A855F7`) and **Electric Blue** (`#00D2FF`).
- **Original Branding**: Custom-designed geometric play symbol entwined with neon film-strip timeline ribbons.
- **Mobile-First Layout**: Fully responsive editing layout optimized for touch targets (48dp+) and thumb reach.

### 2. Home Screen & Project Management
- **Hero New Project Creator**: Instant aspect ratio selector (`9:16`, `16:9`, `1:1`, `4:5`).
- **Android Photo/Video Picker**: Direct integration with system media picker (zero broad storage permissions needed).
- **Interactive Demo Project**: One-tap demo trailer generation with starter clips, titles, and transitions.
- **Recent Projects Grid**: Room-backed persistent storage of project drafts with thumbnails, durations, and timestamps.
- **Project Actions**: Rename, duplicate, delete, and direct export.

### 3. Professional Video Editor Workspace
- **Top Studio Bar**: Back navigation (auto-saving), project rename, undo/redo history, manual save, and 1-tap export.
- **Real-Time Preview Canvas**:
  - Live video and frame playback with frame-stepping controls (`-1s`, `+1s`, Play/Pause).
  - Exact Aspect Ratio framing (fit and fill modes, customizable background color, background blur).
  - Real-time overlay rendering for subtitles, typography, and stickers.
  - Active color filter simulation (Noir B&W, Vibrant, Cinematic, Warm Sunset, Cool Ice, Cyber Neon, Vintage).
- **Multi-Track Horizontal Timeline**:
  - Time ruler with precise second/millisecond tick marks.
  - Draggable glowing cyan playhead needle.
  - **Track 1**: Text & Subtitles track.
  - **Track 2**: Main video track with clip thumbnails, durations, active selection borders, and draggable start/end trim handles.
  - **Track 3**: Audio & voice-over track with volume badges.
  - Timeline zoom controls (`50%` to `300%`).
  - Clip operations: Split at playhead, duplicate, trim, delete, speed change, rotate, flip.

### 4. Editing Tools
- **Clip Editing**: Trimming, splitting, duplicating, reordering, deleting, 90° rotation, horizontal/vertical flipping, opacity control.
- **Speed Control**: Slow motion (0.25x, 0.5x) to fast motion (1.5x, 2.0x, 4.0x) with timeline duration compensation.
- **Canvas Ratios**: 9:16 Vertical (Reels/Shorts/TikTok), 16:9 Landscape (YouTube), 1:1 Square (Instagram Feed), 4:5 Portrait.
- **Color Adjustments**: Brightness, Contrast, Saturation, Temperature, and Tint with 1-tap reset.
- **Audio & Voice-over**: Custom music file import and live microphone voice-over recording using Android's `MediaRecorder`.
- **Text & Subtitles**: Customizable font sizing, colors, background styling, entrance animations (Fade, Zoom, Slide), and support for English and Hindi typography.
- **Cinematic Transitions**: Dissolve, Fade, Slide Left, Slide Right, Zoom In, Wipe between clips.

### 5. Genuine Multimedia Processing Engine
- Powered by **AndroidX Media3 Transformer** (`androidx.media3:media3-transformer`, `media3-effect`, `media3-exoplayer`).
- Transcodes multi-clip compositions, trim boundaries, aspect-ratio scaling (`Presentation.createForAspectRatio`), and video filters to real MP4 files.
- Saved to device's public `Movies/VynoxStudio` directory and registered with MediaStore.

### 6. Watermark-Free Export
- **Zero Watermarks**: Exported videos contain **NO** logos, text watermarks, promotional outros, or end cards.
- **Export Configurations**:
  - Resolutions: `480p SD`, `720p HD`, `1080p Full HD`.
  - Frame Rates: `24 FPS (Cinematic)`, `30 FPS (Standard)`, `60 FPS (Smooth)`.
  - Quality Bitrates: `Standard`, `High`, `Ultra`.
- **Live Progress**: Real-time progress bar, percentage readout, cancel option, and one-tap "Open Video" / "Share Video".

---

---

## 🚀 GitHub Se Kaise Install Kare (How to Install & Run from GitHub)

### Option 1: Direct APK Download via GitHub Actions (Sabse Aasan Tarika)
1. Repository ko apne GitHub account par push karein ya fork karein.
2. GitHub repository open karke **Actions** tab par jayein.
3. **Build Vynox Studio APK** workflow automatically run hoga.
4. Run complete hone par **Artifacts** section mein se `VynoxStudio-APK.zip` download karein.
5. Zip file extract karein aur `app-debug.apk` ko apne Android phone mein direct install karein.

---

### Option 2: Android Studio Mein Open Karna
1. Terminal / Git Bash se clone karein:
   ```bash
   git clone https://github.com/<your-username>/<repo-name>.git
   cd <repo-name>
   ```
2. **Android Studio** open karein aur **Open an Existing Project** select karke project folder choose karein.
3. Gradle sync complete hone dein.
4. Apna Android phone USB se connect karein ya Emulator select karein.
5. Green **Run (Shift + F10)** button par click karein.

---

### Option 3: Terminal / Command Line Se Build Karna

#### Mac / Linux:
```bash
# Debug keystore restore karein
base64 -d debug.keystore.base64 > debug.keystore

# APK build karein
./gradlew assembleDebug

# Apne phone par install karein (USB debugging ON hone par)
./gradlew installDebug
```

#### Windows (PowerShell / CMD):
```powershell
# Debug keystore restore karein
certutil -decode debug.keystore.base64 debug.keystore

# APK build karein
gradlew.bat assembleDebug

# Phone par install karein
gradlew.bat installDebug
```

Output APK yahan milega:
📁 `app/build/outputs/apk/debug/app-debug.apk`

---

## 🧪 Unit & Robolectric Tests
```bash
./gradlew testDebugUnitTest
```
