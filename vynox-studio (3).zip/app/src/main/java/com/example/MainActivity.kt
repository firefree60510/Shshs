package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.editor.EditorScreen
import com.example.ui.export.ExportScreen
import com.example.ui.home.HomeScreen
import com.example.ui.theme.VynoxStudioTheme
import com.example.viewmodel.EditorViewModel
import com.example.viewmodel.ExportViewModel
import com.example.viewmodel.HomeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VynoxStudioTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VynoxAppNavigation()
                }
            }
        }
    }
}

@Composable
fun VynoxAppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            val homeViewModel: HomeViewModel = viewModel()
            HomeScreen(
                viewModel = homeViewModel,
                onOpenEditor = { projectId ->
                    navController.navigate("editor/$projectId")
                },
                onOpenExport = { projectId ->
                    navController.navigate("export/$projectId")
                }
            )
        }

        composable(
            route = "editor/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: ""
            val editorViewModel: EditorViewModel = viewModel()
            EditorScreen(
                projectId = projectId,
                viewModel = editorViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateExport = { targetProjectId ->
                    navController.navigate("export/$targetProjectId")
                }
            )
        }

        composable(
            route = "export/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: ""
            val exportViewModel: ExportViewModel = viewModel()
            ExportScreen(
                projectId = projectId,
                viewModel = exportViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
