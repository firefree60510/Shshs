package com.example.model

import java.util.UUID

data class VynoxProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Project",
    val createdAt: Long = System.currentTimeMillis(),
    val lastModifiedAt: Long = System.currentTimeMillis(),
    val aspectRatio: AspectRatio = AspectRatio.RATIO_9_16,
    val canvasBgColorHex: Long = 0xFF000000,
    val canvasBlurBg: Boolean = false,
    val fitMode: CanvasFitMode = CanvasFitMode.FIT,
    val videoClips: List<VideoClip> = emptyList(),
    val audioClips: List<AudioClip> = emptyList(),
    val textOverlays: List<TextOverlay> = emptyList(),
    val imageOverlays: List<ImageOverlay> = emptyList(),
    val transitions: List<ClipTransition> = emptyList(),
    val colorAdjustments: ColorAdjustments = ColorAdjustments(),
    val thumbnailUri: String? = null
) {
    val totalDurationMs: Long
        get() {
            val videoDuration = videoClips.sumOf { it.durationMs }
            val audioMax = audioClips.maxOfOrNull { it.startTimelineMs + it.durationMs } ?: 0L
            val textMax = textOverlays.maxOfOrNull { it.endTimelineMs } ?: 0L
            val imageMax = imageOverlays.maxOfOrNull { it.endTimelineMs } ?: 0L
            return maxOf(videoDuration, audioMax, textMax, imageMax, 1000L)
        }

    fun findClipAtTimeline(positionMs: Long): Pair<Int, VideoClip>? {
        var currentOffset = 0L
        for (i in videoClips.indices) {
            val clip = videoClips[i]
            val clipEnd = currentOffset + clip.durationMs
            if (positionMs in currentOffset until clipEnd) {
                return Pair(i, clip)
            }
            currentOffset = clipEnd
        }
        return if (videoClips.isNotEmpty()) Pair(videoClips.lastIndex, videoClips.last()) else null
    }

    fun getClipStartOffset(index: Int): Long {
        var offset = 0L
        for (i in 0 until index.coerceAtMost(videoClips.size)) {
            offset += videoClips[i].durationMs
        }
        return offset
    }
}
