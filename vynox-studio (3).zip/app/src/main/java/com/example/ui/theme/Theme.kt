package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VynoxColorScheme = darkColorScheme(
    primary = VynoxPurple,
    onPrimary = Color.White,
    primaryContainer = VynoxPurpleDark,
    onPrimaryContainer = Color.White,
    secondary = VynoxElectricBlue,
    onSecondary = Color.Black,
    secondaryContainer = VynoxBlueDark,
    onSecondaryContainer = Color.White,
    tertiary = VynoxAccentPink,
    onTertiary = Color.White,
    background = VynoxBlack,
    onBackground = VynoxTextPrimary,
    surface = VynoxDarkSurface,
    onSurface = VynoxTextPrimary,
    surfaceVariant = VynoxCardSurface,
    onSurfaceVariant = VynoxTextSecondary,
    outline = VynoxBorder,
    outlineVariant = VynoxElevatedSurface
)

@Composable
fun VynoxStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VynoxColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    VynoxStudioTheme(content = content)
}
