package com.example.viewmodel

import android.app.Application
import android.graphics.Color
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectRepository
import com.example.engine.VynoxMediaHelper
import com.example.model.AspectRatio
import com.example.model.AudioClip
import com.example.model.ClipTransition
import com.example.model.FilterEffect
import com.example.model.TextAnimation
import com.example.model.TextOverlay
import com.example.model.TransitionType
import com.example.model.VideoClip
import com.example.model.VynoxProject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ProjectRepository(application)

    val projects: StateFlow<List<VynoxProject>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _lastCreatedProjectId = MutableStateFlow<String?>(null)
    val lastCreatedProjectId: StateFlow<String?> = _lastCreatedProjectId.asStateFlow()

    fun resetCreatedProjectId() {
        _lastCreatedProjectId.value = null
    }

    fun createProjectFromMedia(name: String, aspectRatio: AspectRatio, uris: List<Uri>) {
        viewModelScope.launch {
            _isBusy.value = true
            val clips = mutableListOf<VideoClip>()
            var thumbUri: String? = null

            for ((index, uri) in uris.withIndex()) {
                val mediaInfo = VynoxMediaHelper.inspectMedia(getApplication(), uri)
                if (index == 0) {
                    thumbUri = VynoxMediaHelper.getThumbnail(getApplication(), uri) ?: uri.toString()
                }
                clips.add(
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        uri = uri.toString(),
                        name = "Clip ${index + 1}",
                        isImage = !mediaInfo.isVideo,
                        sourceDurationMs = mediaInfo.durationMs,
                        trimStartMs = 0L,
                        trimEndMs = mediaInfo.durationMs
                    )
                )
            }

            val project = VynoxProject(
                id = UUID.randomUUID().toString(),
                name = name.ifBlank { "Vynox Project" },
                aspectRatio = aspectRatio,
                videoClips = clips,
                thumbnailUri = thumbUri ?: clips.firstOrNull()?.uri
            )

            repository.saveProject(project)
            _isBusy.value = false
            _lastCreatedProjectId.value = project.id
        }
    }

    /**
     * Creates a high-fidelity starter project with generated media, titles, and transitions.
     */
    fun createSampleProject(aspectRatio: AspectRatio = AspectRatio.RATIO_9_16) {
        viewModelScope.launch {
            _isBusy.value = true
            val context = getApplication<Application>()

            val uri1 = VynoxMediaHelper.generateSampleGraphic(
                context,
                "CYBER VIBES",
                "Cinematic Neon Trailer",
                Color.rgb(18, 12, 38),
                Color.rgb(168, 85, 247)
            )

            val uri2 = VynoxMediaHelper.generateSampleGraphic(
                context,
                "LIMITLESS",
                "Create Beyond Limits",
                Color.rgb(10, 25, 47),
                Color.rgb(0, 210, 255)
            )

            val clip1 = VideoClip(
                id = UUID.randomUUID().toString(),
                uri = uri1.toString(),
                name = "Intro Scene",
                isImage = true,
                sourceDurationMs = 4000L,
                trimStartMs = 0L,
                trimEndMs = 4000L,
                filterEffect = FilterEffect.VIBRANT
            )

            val clip2 = VideoClip(
                id = UUID.randomUUID().toString(),
                uri = uri2.toString(),
                name = "Highlight Reel",
                isImage = true,
                sourceDurationMs = 5000L,
                trimStartMs = 0L,
                trimEndMs = 5000L,
                filterEffect = FilterEffect.CYBERPUNK
            )

            val textOverlay = TextOverlay(
                id = UUID.randomUUID().toString(),
                text = "Vynox Studio",
                fontSizeSp = 28f,
                textColorHex = 0xFF00D2FF,
                outlineColorHex = 0xFF000000,
                xPercent = 0.5f,
                yPercent = 0.35f,
                startTimelineMs = 500L,
                endTimelineMs = 6000L,
                animation = TextAnimation.ZOOM
            )

            val transition = ClipTransition(
                clipIndex = 0,
                type = TransitionType.DISSOLVE,
                durationMs = 600L
            )

            val project = VynoxProject(
                id = UUID.randomUUID().toString(),
                name = "Demo: Neon Future",
                aspectRatio = aspectRatio,
                videoClips = listOf(clip1, clip2),
                textOverlays = listOf(textOverlay),
                transitions = listOf(transition),
                thumbnailUri = uri1.toString()
            )

            repository.saveProject(project)
            _isBusy.value = false
            _lastCreatedProjectId.value = project.id
        }
    }

    fun duplicateProject(project: VynoxProject) {
        viewModelScope.launch {
            repository.duplicateProject(project)
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
        }
    }

    fun renameProject(project: VynoxProject, newName: String) {
        viewModelScope.launch {
            val updated = project.copy(
                name = newName.ifBlank { project.name },
                lastModifiedAt = System.currentTimeMillis()
            )
            repository.saveProject(updated)
        }
    }
}
